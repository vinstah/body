<?php
//define global path to Components' root folder
if(!defined('GRIDFIELD_GALLERY_THEME_PATH'))
{
	define('GRIDFIELD_GALLERY_THEME_PATH', rtrim(basename(dirname(__FILE__))));
}