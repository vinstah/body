{
    "LeftAndMain.CONFIRMUNSAVED": "Вы действительно хотите покинуть эту страницу?\n\nВНИМАНИЕ: Ваши изменения не были сохранены.\n\nНажмите ОК, чтобы продолжить или Отмена, чтобы остаться на текущей странице.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "ВНИМАНИЕ: Ваши изменения не были сохранены",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Вы действительно хотите удалить %s групп?",
    "ModelAdmin.SAVED": "Сохранено",
    "ModelAdmin.REALLYDELETE": "Вы действительно хотите удалить?",
    "ModelAdmin.DELETED": "Удалено",
    "ModelAdmin.VALIDATIONERROR": "Ошибка валидации",
    "LeftAndMain.PAGEWASDELETED": "Эта страница была удалена. Чтобы изменить страницу, выберите её из списка слева."
}