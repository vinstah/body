{
    "LeftAndMain.CONFIRMUNSAVED": "Haluatko varmasti poistua tältä sivulta?\n\nVAROITUS: Muutoksiasi ei ole tallennettu.\n\nPaina OK jatkaaksesi, tai Peruuta pysyäksesi nykyisellä sivulla.",
    "LeftAndMain.CONFIRMUNSAVEDSHORT": "VAROITUS: Muutoksiasi ei ole tallennettu.",
    "SecurityAdmin.BATCHACTIONSDELETECONFIRM": "Haluatko varmasti poistaa %s ryhmät?",
    "ModelAdmin.SAVED": "Tallennettu",
    "ModelAdmin.REALLYDELETE": "Haluatko varmasti poistaa?",
    "ModelAdmin.DELETED": "Poistettu",
    "ModelAdmin.VALIDATIONERROR": "Virhe vahvistuksessa",
    "LeftAndMain.PAGEWASDELETED": "Sivu on poistettu. Valitse sivu muokattavaksesi vasemmalta."
}