;(function($) {
	$(document).ready(function() {
		$(".fancybox").fancybox();
	});
}(jQuery));