<?php
class AboutPage extends Page {

	private static $db = array(
	);
	private static $has_one = array(
	);
	private static $allowed_children = 'none';
	private static $can_be_root = false;	

}
class AboutPage_Controller extends Page_Controller {

	private static $allowed_actions = array (
	);
	
}