<?php

if(!defined('USERFORMS_DIR')) {
	define('USERFORMS_DIR', basename(__DIR__));
}
