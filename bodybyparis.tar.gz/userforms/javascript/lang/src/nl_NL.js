{
    "UserForms.CONFIRM_DELETE_ALL_SUBMISSIONS": "Alle inzendingen zullen permanent worden verwijderd. Doorgaan?",
    "UserForms.ERROR_CREATING_FIELD": "Fout bij het maken optie",
    "UserForms.ADDING_FIELD": "Nieuw veld toe te voegen",
    "UserForms.ADDED_FIELD": "Nieuw veld toegevoegd",
    "UserForms.HIDE_OPTIONS": "Verberg opties",
    "UserForms.SHOW_OPTIONS": "Toon opties",
    "UserForms.ADDING_OPTION": "Nieuwe optie toevoegen",
    "UserForms.ADDED_OPTION": "Toegevoegde optie",
    "UserForms.ERROR_CREATING_OPTION": "Fout bij het maken optie",
    "UserForms.REMOVED_OPTION": "Verwijder optie",
    "UserForms.ADDING_RULE": "Regel toevoegen",
    "GRIDFIELD.ERRORINTRANSACTION": "Er is een fout opgetreden tijdens het ophalen van gegevens van de server.\nProbeer het later opnieuw."
}